package com.reygameturbo.rgt.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.RemoteException
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class ShizukuManager(private val context: Context) {
    enum class State { NOT_RUNNING, NOT_PERMISSION, READY }

    companion object { const val REQUEST_CODE = 4107 }

    @Volatile private var remote: IUserService? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val args = Shizuku.UserServiceArgs(
        ComponentName(context, UserService::class.java)
    ).daemon(false).processNameSuffix("rgt_priv").version(1).tag("rgt-user-service")

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IUserService.Stub.asInterface(service)
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
        }
    }

    fun state(): State {
        if (!Shizuku.pingBinder()) return State.NOT_RUNNING
        return try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) State.READY
            else State.NOT_PERMISSION
        } catch (_: Throwable) {
            State.NOT_PERMISSION
        }
    }

    fun requestPermission() {
        try {
            if (state() == State.NOT_PERMISSION) Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Throwable) { }
    }

    fun bindIfReady(): Boolean {
        if (state() != State.READY) return false
        return try {
            Shizuku.bindUserService(args, connection)
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun execute(action: String, callback: (String) -> Unit) {
        if (!bindIfReady()) {
            callback("Shizuku is not ready")
            return
        }
        executor.execute {
            val result = try {
                val service = remote
                if (service == null) "UserService not connected yet" else service.execute(action)
            } catch (e: RemoteException) {
                "Remote error: ${e.message}"
            } catch (e: Throwable) {
                "Error: ${e.message}"
            }
            callback(result)
        }
    }

    fun shutdown() {
        try { Shizuku.unbindUserService(args, connection, true) } catch (_: Throwable) { }
        executor.shutdownNow()
        remote = null
    }
}
