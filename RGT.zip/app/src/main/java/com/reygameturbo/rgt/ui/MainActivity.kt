package com.reygameturbo.rgt.ui

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.reygameturbo.rgt.R
import com.reygameturbo.rgt.overlay.RgtOverlayService
import com.reygameturbo.rgt.shizuku.ShizukuManager
import rikka.shizuku.Shizuku
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var shizuku: ShizukuManager
    private lateinit var adapter: GameAdapter
    private var allApps = listOf<AppInfo>()
    private var showGames = true
    private var lastProfileApp: AppInfo? = null

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        shizuku = ShizukuManager(this)
        setupUi()
        refreshApps()
        updateDashboard()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun setupUi() {
        val list = findViewById<RecyclerView>(R.id.gameList)
        list.layoutManager = LinearLayoutManager(this)
        adapter = GameAdapter(::launchApp, ::showGameProfile)
        list.adapter = adapter

        findViewById<EditText>(R.id.searchInput).addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = filterApps(s?.toString().orEmpty())
            override fun afterTextChanged(s: android.text.Editable?) = Unit
        })
        findViewById<Button>(R.id.filterGames).setOnClickListener { showGames = true; updateFilters() }
        findViewById<Button>(R.id.filterApps).setOnClickListener { showGames = false; updateFilters() }
        findViewById<Button>(R.id.turboButton).setOnClickListener { showTurboDialog() }
        findViewById<Button>(R.id.smoothButton).setOnClickListener { showSmoothDialog() }
        findViewById<Button>(R.id.crosshairButton).setOnClickListener { showCrosshairSettings() }
        findViewById<Button>(R.id.monitorButton).setOnClickListener { showMonitorDialog() }
        findViewById<Button>(R.id.shizukuButton).setOnClickListener { showShizukuDialog() }
        findViewById<TextView>(R.id.shizukuChip).setOnClickListener { showShizukuDialog() }
    }

    private fun refreshApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolves = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        allApps = resolves.mapNotNull { ri ->
            val info = ri.activityInfo ?: return@mapNotNull null
            if (info.packageName == packageName) return@mapNotNull null
            val launch = Intent(intent).setPackage(info.packageName)
            val label = info.loadLabel(pm)?.toString()?.ifBlank { info.packageName } ?: info.packageName
            val isGame = if (Build.VERSION.SDK_INT >= 26) {
                (info.applicationInfo.category == android.content.pm.ApplicationInfo.CATEGORY_GAME)
            } else false
            AppInfo(info.packageName, label, info.loadIcon(pm), launch, isGame)
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
        updateFilters()
    }

    private fun updateFilters() { filterApps(findViewById<EditText>(R.id.searchInput).text.toString()) }

    private fun filterApps(query: String) {
        val q = query.trim().lowercase(Locale.getDefault())
        val prefs = getSharedPreferences("rgt", MODE_PRIVATE)
        val filtered = allApps.filter { app ->
            val categoryMatch = if (showGames) app.isGame else !app.isGame
            categoryMatch && (q.isBlank() || app.label.lowercase().contains(q) || app.packageName.lowercase().contains(q))
        }.sortedWith(compareByDescending<AppInfo> { prefs.getLong("last_${it.packageName}", 0L) }.thenBy { it.label.lowercase(Locale.getDefault()) })
        adapter.submit(filtered)
        findViewById<TextView>(R.id.emptyText).visibility = if (filtered.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun launchApp(app: AppInfo) {
        lastProfileApp = app
        try {
            getSharedPreferences("rgt", MODE_PRIVATE).edit().putLong("last_${app.packageName}", System.currentTimeMillis()).apply()
            startActivity(app.launchIntent)
        } catch (e: Exception) { toast("Launch failed: ${e.message}") }
    }

    private fun showGameProfile(app: AppInfo) {
        lastProfileApp = app
        val view = layoutInflater.inflate(R.layout.dialog_game_profile, null)
        view.findViewById<TextView>(R.id.profileName).text = app.label
        view.findViewById<TextView>(R.id.profilePackage).text = app.packageName
        view.findViewById<TextView>(R.id.profileInfo).text = "Turbo and Smooth use only supported Android/vendor controls. FPS is not fabricated when Android does not expose target-app frame data."
        val dialog = MaterialAlertDialogBuilder(this).setView(view).create()
        view.findViewById<Button>(R.id.profileLaunch).setOnClickListener { dialog.dismiss(); launchApp(app) }
        val prefs = getSharedPreferences("rgt", MODE_PRIVATE)
        val key = "library_${app.packageName}"
        val toggle = view.findViewById<Button>(R.id.profileToggle)
        toggle.text = if (prefs.getBoolean(key, false)) "Remove from RGT Library" else "Add to RGT Library"
        toggle.setOnClickListener {
            val next = !prefs.getBoolean(key, false)
            prefs.edit().putBoolean(key, next).apply()
            toggle.text = if (next) "Remove from RGT Library" else "Add to RGT Library"
            toast(if (next) "Added to RGT Library" else "Removed from RGT Library")
        }
        view.findViewById<Button>(R.id.profileTurbo).setOnClickListener { applyTurbo(true) }
        view.findViewById<Button>(R.id.profileSmooth).setOnClickListener { dialog.dismiss(); showSmoothDialog() }
        view.findViewById<Button>(R.id.profileCrosshair).setOnClickListener { dialog.dismiss(); showCrosshairSettings() }
        view.findViewById<Button>(R.id.profileSidebar).setOnClickListener { startSidebar() }
        dialog.show()
    }

    private fun showTurboDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Turbo Mode")
            .setMessage("RGT can reduce Android animation scales through Shizuku and report the command result. This does not guarantee FPS or bypass a game's limits.")
            .setPositiveButton("Enable") { _, _ -> applyTurbo(true) }
            .setNegativeButton("Restore") { _, _ -> applyTurbo(false) }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun applyTurbo(enable: Boolean) {
        shizuku.execute(if (enable) "turbo_on" else "turbo_off") { result ->
            runOnUiThread { toast(if (result.startsWith("exit=0")) "Turbo command completed" else result) }
        }
    }

    private fun showSmoothDialog() {
        val options = arrayOf("Standard", "Smooth", "Ultra Smooth", "Custom")
        MaterialAlertDialogBuilder(this)
            .setTitle("Screen Smoothness")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> setRefreshProfile(60f)
                    1 -> setRefreshProfile(90f)
                    2 -> setRefreshProfile(120f)
                    3 -> showCustomRefresh()
                }
            }.show()
    }

    private fun showCustomRefresh() {
        val rates = supportedRefreshRates()
        val labels = rates.map { "${it.toInt()} Hz" }.toTypedArray()
        if (rates.isEmpty()) { toast("Not supported on this device"); return }
        MaterialAlertDialogBuilder(this).setTitle("Custom refresh rate").setItems(labels) { _, which -> setRefreshProfile(rates[which]) }.show()
    }

    private fun supportedRefreshRates(): List<Float> {
        return windowManager.defaultDisplay.supportedModes.map { it.refreshRate }.distinct().sorted()
    }

    private fun setRefreshProfile(rate: Float) {
        val max = supportedRefreshRates().maxOrNull() ?: 60f
        if (rate > max + 0.1f) { toast("Not supported on this device"); return }
        val action = when {
            rate >= 143f -> "refresh_144"
            rate >= 115f -> "refresh_120"
            rate >= 85f -> "refresh_90"
            else -> "refresh_60"
        }
        shizuku.execute(action) { result ->
            runOnUiThread { toast(if (result.startsWith("exit=0")) "Refresh profile command completed" else result) }
        }
    }


    private fun showCrosshairSettings() {
        val prefs = getSharedPreferences("crosshair", MODE_PRIVATE)
        val root = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(24, 8, 24, 4) }
        fun label(text: String): TextView = TextView(this).apply { this.text = text; setTextColor(Color.WHITE); textSize = 13f }
        val size = android.widget.SeekBar(this).apply { max = 48; progress = prefs.getInt("size", 22) }
        val opacity = android.widget.SeekBar(this).apply { max = 80; progress = prefs.getInt("opacity", 80) }
        val shape = android.widget.Spinner(this).apply { adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Cross", "Dot", "Plus", "Circle")); setSelection(prefs.getInt("shape", 0)) }
        val color = android.widget.Spinner(this).apply { adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("White", "Red", "Green", "Yellow")); setSelection(prefs.getInt("color", 0)) }
        root.addView(label("Size")); root.addView(size); root.addView(label("Opacity")); root.addView(opacity); root.addView(label("Shape")); root.addView(shape); root.addView(label("Color")); root.addView(color)
        val dialog = MaterialAlertDialogBuilder(this).setTitle("Visual Crosshair").setView(root).setPositiveButton("Save", null).setNegativeButton("Cancel", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                prefs.edit().putInt("size", size.progress).putInt("opacity", opacity.progress).putInt("shape", shape.selectedItemPosition).putInt("color", color.selectedItemPosition).apply()
                if (!Settings.canDrawOverlays(this)) { dialog.dismiss(); toggleCrosshair(); return@setOnClickListener }
                startOverlayService(Intent(this, RgtOverlayService::class.java).putExtra("action", "crosshair_apply"))
                dialog.dismiss()
            }
        }
        dialog.setNeutralButton("Reset position") { _, _ -> if (Settings.canDrawOverlays(this)) startOverlayService(Intent(this, RgtOverlayService::class.java).putExtra("action", "crosshair_reset")) }
        dialog.show()
    }

    private fun toggleCrosshair() {
        if (!Settings.canDrawOverlays(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Overlay permission")
                .setMessage("RGT needs Android's display-over-other-apps permission for a visual-only crosshair and sidebar.")
                .setPositiveButton("Open settings") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }.setNegativeButton("Cancel", null).show()
            return
        }
        val i = Intent(this, RgtOverlayService::class.java).putExtra("action", "crosshair_toggle")
        startOverlayService(i)
    }

    private fun startSidebar() {
        if (!Settings.canDrawOverlays(this)) { toggleCrosshair(); return }
        startOverlayService(Intent(this, RgtOverlayService::class.java).putExtra("action", "sidebar_show"))
    }

    private fun startOverlayService(intent: Intent) {
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) { toast("Overlay service failed: ${e.message}") }
    }

    private fun showMonitorDialog() {
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val mem = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val pct = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)?.takeIf { it >= 0 }?.toString()?.plus("%") ?: "Unavailable"
        val temp = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.let { if (it != Int.MIN_VALUE) String.format(Locale.US, "%.1f°C", it / 10f) else "Unavailable" } ?: "Unavailable"
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val thermal = if (Build.VERSION.SDK_INT >= 29) thermalText(pm.currentThermalStatus) else "Unavailable"
        val refresh = supportedRefreshRates().maxOrNull()?.let { "%.0f Hz max".format(Locale.US, it) } ?: "Unavailable"
        val sh = shizuku.state().name.replace('_', ' ')
        val text = "RAM available: ${mem.availMem / 1048576} MB\nRAM total: ${mem.totalMem / 1048576} MB\nBattery: $pct\nBattery temp: $temp\nThermal: $thermal\nDisplay: $refresh\nFPS target app: Unavailable (public API)\nShizuku: $sh"
        MaterialAlertDialogBuilder(this).setTitle("RGT Performance Monitor").setMessage(text).setPositiveButton("Close", null).show()
    }

    private fun thermalText(status: Int): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Normal"
        PowerManager.THERMAL_STATUS_LIGHT -> "Light"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
        PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
        else -> "Unavailable"
    }

    private fun showShizukuDialog() {
        val state = shizuku.state()
        val message = when (state) {
            ShizukuManager.State.NOT_RUNNING -> "SHIZUKU NOT RUNNING\nInstall/start Shizuku first. RGT remains usable without it."
            ShizukuManager.State.NOT_PERMISSION -> "SHIZUKU NOT PERMISSION\nShizuku is detected, but RGT has not been granted permission."
            ShizukuManager.State.READY -> "SHIZUKU READY\nRGT can bind its UserService for supported operations."
        }
        val builder = MaterialAlertDialogBuilder(this).setTitle("Shizuku status").setMessage(message).setPositiveButton("Close", null)
        if (state == ShizukuManager.State.NOT_PERMISSION) builder.setNegativeButton("Request permission") { _, _ -> shizuku.requestPermission() }
        builder.show()
    }

    private fun updateDashboard() {
        val games = allApps.count { it.isGame }
        val ram = (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).let { am -> android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.availMem / 1048576 }
        val gamesCard = findViewById<android.view.View>(R.id.cardGames)
        gamesCard.findViewById<TextView>(R.id.statTitle).text = "GAMES"
        gamesCard.findViewById<TextView>(R.id.statValue).text = games.toString()
        val ramCard = findViewById<android.view.View>(R.id.cardRam)
        ramCard.findViewById<TextView>(R.id.statTitle).text = "RAM FREE"
        ramCard.findViewById<TextView>(R.id.statValue).text = "${ram}MB"
        val chip = findViewById<TextView>(R.id.shizukuChip)
        chip.text = when (shizuku.state()) {
            ShizukuManager.State.NOT_RUNNING -> "SHIZUKU OFF"
            ShizukuManager.State.NOT_PERMISSION -> "SHIZUKU !"
            ShizukuManager.State.READY -> "SHIZUKU OK"
        }
        chip.setTextColor(if (shizuku.state() == ShizukuManager.State.READY) Color.WHITE else Color.LTGRAY)
    }

    override fun onResume() { super.onResume(); if (::shizuku.isInitialized) updateDashboard() }
    override fun onDestroy() { if (::shizuku.isInitialized) shizuku.shutdown(); super.onDestroy() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
