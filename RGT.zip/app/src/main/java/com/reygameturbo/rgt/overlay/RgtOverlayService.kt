package com.reygameturbo.rgt.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.reygameturbo.rgt.R
import java.util.Locale

class RgtOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var crosshair: TextView? = null
    private var sidebar: View? = null
    private var running = false
    private var offsetX = 0
    private var offsetY = 0

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        if (Build.VERSION.SDK_INT >= 26) {
            startForeground(9001, NotificationCompat.Builder(this, "rgt_overlay")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("ReyGameTurbo")
                .setContentText("Gaming overlay is active")
                .setOngoing(true)
                .build())
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        when (intent?.getStringExtra("action")) {
            "crosshair_toggle" -> toggleCrosshair()
            "crosshair_apply" -> applyCrosshairConfig()
            "crosshair_reset" -> resetCrosshair()
            "sidebar_show" -> showSidebar()
            "sidebar_hide" -> hideSidebar()
        }
        return START_STICKY
    }

    private fun overlayParams(width: Int, height: Int, flags: Int): WindowManager.LayoutParams = WindowManager.LayoutParams(
        width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

    private fun toggleCrosshair() {
        if (crosshair != null) {
            wm.removeView(crosshair); crosshair = null; return
        }
        val prefs = getSharedPreferences("crosshair", MODE_PRIVATE)
        val view = TextView(this).apply {
            text = crosshairGlyph(prefs.getInt("shape", 0))
            textSize = (prefs.getInt("size", 22) + 16).toFloat()
            setTextColor(crosshairColor(prefs.getInt("color", 0)))
            alpha = (prefs.getInt("opacity", 80) + 20) / 100f
            setShadowLayer(5f, 0f, 0f, Color.BLACK)
            gravity = Gravity.CENTER
            contentDescription = "RGT visual crosshair"
            setOnTouchListener(DragTouch())
        }
        val box = (prefs.getInt("size", 22) + 60).coerceIn(64, 140)
        val p = overlayParams(box, box, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        p.x = prefs.getInt("x", resources.displayMetrics.widthPixels / 2 - box / 2)
        p.y = prefs.getInt("y", resources.displayMetrics.heightPixels / 2 - box / 2)
        try { wm.addView(view, p); crosshair = view } catch (_: Exception) { }
    }

    private inner class DragTouch : View.OnTouchListener {
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = v.layoutParams as WindowManager.LayoutParams
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = p.x; startY = p.y; return true }
                MotionEvent.ACTION_MOVE -> { p.x = startX + (event.rawX - downX).toInt(); p.y = startY + (event.rawY - downY).toInt(); wm.updateViewLayout(v, p); getSharedPreferences("crosshair", MODE_PRIVATE).edit().putInt("x", p.x).putInt("y", p.y).apply(); return true }
            }
            return false
        }
    }

    private fun crosshairGlyph(shape: Int): String = when (shape) {
        1 -> "•"
        2 -> "+"
        3 -> "⊙"
        else -> "⊕"
    }

    private fun crosshairColor(color: Int): Int = when (color) {
        1 -> Color.RED
        2 -> Color.GREEN
        3 -> Color.YELLOW
        else -> Color.WHITE
    }

    private fun applyCrosshairConfig() {
        if (crosshair != null) {
            try { wm.removeView(crosshair) } catch (_: Exception) {}
            crosshair = null
            toggleCrosshair()
        } else toggleCrosshair()
    }

    private fun resetCrosshair() {
        val prefs = getSharedPreferences("crosshair", MODE_PRIVATE)
        prefs.edit().remove("x").remove("y").apply()
        if (crosshair != null) {
            try { wm.removeView(crosshair) } catch (_: Exception) {}
            crosshair = null
            toggleCrosshair()
        }
    }

    private fun showSidebar() {
        if (sidebar != null) return
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 12, 12, 12) }
        val title = TextView(this).apply { text = "RGT SIDEBAR"; setTextColor(Color.WHITE); textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
        val stats = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 10f; text = monitorText() }
        root.addView(title); root.addView(stats)
        fun add(text: String, action: () -> Unit) { root.addView(Button(this).apply { this.text = text; textSize = 10f; setOnClickListener { action() } }) }
        add("Turbo") { toast("Turbo is controlled from RGT app") }
        add("Smooth") { toast("Smoothness profiles are controlled from RGT app") }
        add("Crosshair") { toggleCrosshair() }
        add("Brightness") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        add("Volume") { (getSystemService(AUDIO_SERVICE) as AudioManager).adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
        add("Screen rotation") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
        add("Performance info") { stats.text = monitorText() }
        add("Thermal info") { stats.text = monitorText() }
        add("FPS info") { stats.text = "FPS: Unavailable\nAndroid public APIs do not expose target-app FPS here." }
        add("Close") { hideSidebar() }
        val p = overlayParams(190, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
        p.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        p.x = 8
        try { wm.addView(root, p); sidebar = root } catch (_: Exception) { }
    }

    private fun hideSidebar() { sidebar?.let { wm.removeView(it) }; sidebar = null }

    private fun monitorText(): String {
        val am = getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager
        val mem = android.app.ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val battery = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)?.let { if (it >= 0) "$it%" else "Unavailable" } ?: "Unavailable"
        val temp = battery?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)?.let { if (it != Int.MIN_VALUE) String.format(Locale.US, "%.1f°C", it / 10f) else "Unavailable" } ?: "Unavailable"
        return "RAM free: ${mem.availMem / 1048576} MB\nBattery: $level\nTemp: $temp\nFPS: Unavailable"
    }

    private fun toast(message: String) = android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("rgt_overlay", "RGT Gaming Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        crosshair?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        sidebar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        crosshair = null; sidebar = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
