# RGT keeps its Shizuku UserService and AIDL implementation discoverable.
-keep class com.reygameturbo.rgt.shizuku.UserService { *; }
-keep interface com.reygameturbo.rgt.shizuku.IUserService { *; }
